public class TemperatureConversion {
    public static void main(String[] args) {

        // Store temperature in Celsius
        int celsius = 50;

        // Convert Celsius to Fahrenheit
        double fahrenheit = (celsius * 9.0 / 5.0) + 32;

        // Display the values
        System.out.println("Temperature in Celsius: " + celsius + " °C");
        System.out.println("Temperature in Fahrenheit: " + fahrenheit + " °F");
    }
}